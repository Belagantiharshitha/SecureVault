from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# Your .json file path
SERVICE_ACCOUNT_FILE = 'securevault-key.json'

# Scope for uploading to Drive
SCOPES = ['https://www.googleapis.com/auth/drive.file']

# Authenticate with service account
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES
)

# Create the Drive service
drive_service = build('drive', 'v3', credentials=credentials)

# Upload file to Google Drive inside specific folder
def upload_to_drive(file_path, file_name, folder_id=None):
    file_metadata = {
        'name': file_name,
        'parents': [folder_id] if folder_id else []
    }
    media = MediaFileUpload(file_path, resumable=True)

    try:
        uploaded_file = drive_service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id'
        ).execute()
        print(f"✅ Uploaded '{file_name}' to Google Drive. File ID: {uploaded_file.get('id')}")
        return uploaded_file.get('id')
    except Exception as e:
        print(f"❌ Error uploading file: {e}")
        raise
