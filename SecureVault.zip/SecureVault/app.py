from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet
from datetime import datetime
from drive_upload import upload_to_drive  # Ensure this file exists and is configured

# --- Flask Setup ---
app = Flask(__name__)
app.secret_key = 'securevault_secret_key'

# --- Upload Folder & Encryption ---
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# --- Persistent Fernet Key ---
FERNET_KEY_FILE = 'fernet.key'
if os.path.exists(FERNET_KEY_FILE):
    with open(FERNET_KEY_FILE, 'rb') as f:
        FERNET_KEY = f.read()
else:
    FERNET_KEY = Fernet.generate_key()
    with open(FERNET_KEY_FILE, 'wb') as f:
        f.write(FERNET_KEY)
fernet = Fernet(FERNET_KEY)

# --- Google Drive Folder ID ---
DRIVE_FOLDER_ID = '1C9DWwn3pT01JW9Wq4Z2Dr-jz7sbyOMaj'

# --- DB Setup ---
def init_db():
    os.makedirs('database', exist_ok=True)
    conn = sqlite3.connect('database/users.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# --- Routes ---

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/register_user', methods=['POST'])
def register_user():
    username = request.form['username']
    password = generate_password_hash(request.form['password'])

    conn = sqlite3.connect('database/users.db')
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        session['username'] = username  # ✅ Auto-login after signup
        flash('Account created successfully!', 'success')
        return redirect(url_for('dashboard'))
    except sqlite3.IntegrityError:
        flash('Username already exists. Try another.', 'danger')
        return redirect(url_for('signup'))
    finally:
        conn.close()

@app.route('/login_user', methods=['POST'])
def login_user():
    username = request.form['username']
    password = request.form['password']

    conn = sqlite3.connect('database/users.db')
    c = conn.cursor()
    c.execute("SELECT password FROM users WHERE username = ?", (username,))
    result = c.fetchone()
    conn.close()

    if result and check_password_hash(result[0], password):
        session['username'] = username
        return redirect(url_for('dashboard'))
    else:
        flash('Invalid username or password', 'danger')
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('dashboard.html', username=session['username'], files=files)

@app.route('/upload', methods=['POST'])
def upload():
    if 'username' not in session:
        return redirect(url_for('login'))

    file = request.files['file']
    if file.filename == '':
        flash('No file selected', 'warning')
        return redirect(url_for('dashboard'))

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    # Encrypt the file
    try:
        data = file.read()
        encrypted = fernet.encrypt(data)
        with open(filepath, 'wb') as f:
            f.write(encrypted)
    except Exception as e:
        flash(f"Encryption failed: {str(e)}", "danger")
        return redirect(url_for('dashboard'))

    # Upload to Google Drive
    try:
        drive_file_id = upload_to_drive(filepath, filename, folder_id=DRIVE_FOLDER_ID)
        print(f"Uploaded to Drive. File ID: {drive_file_id}")
    except Exception as e:
        print("Error uploading to Drive:", e)
        flash("Failed to upload to Google Drive.", "warning")

    # Log upload
    with open('access_logs.txt', 'a') as log:
        log.write(f"{datetime.now()} - {session['username']} uploaded '{filename}' from {request.remote_addr}\n")

    flash('File encrypted & uploaded!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/download/<filename>')
def download(filename):
    if 'username' not in session:
        return redirect(url_for('login'))

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(filepath):
        flash("File not found!", "danger")
        return redirect(url_for('dashboard'))

    try:
        with open(filepath, 'rb') as f:
            encrypted = f.read()
        decrypted = fernet.decrypt(encrypted)
    except Exception as e:
        flash(f"Decryption failed: {str(e)}", "danger")
        return redirect(url_for('dashboard'))

    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], f"temp_{filename}")
    with open(temp_path, 'wb') as f:
        f.write(decrypted)

    # Log download
    with open('access_logs.txt', 'a') as log:
        log.write(f"{datetime.now()} - {session['username']} downloaded '{filename}' from {request.remote_addr}\n")

    response = send_from_directory(app.config['UPLOAD_FOLDER'], f"temp_{filename}", as_attachment=True)

    @response.call_on_close
    def cleanup():
        os.remove(temp_path)

    return response

# --- Run App ---
if __name__ == '__main__':
    app.run(debug=True)
